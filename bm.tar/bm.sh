#!/bin/bash

q=5          # characteristic of the field (edit here)
filename=""  # filename of your target sequence (edit here)

g++ -Wall -o bm berlekamp-massey.cpp -lntl -lgmp && ./bm $q $filename 
