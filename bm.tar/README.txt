
[HOW TO RUN]
  1. Edit the variables "q" and "filename" in bm.sh 

  2. Change the permission of bm.sh

  3. Run bm.sh


[Note]
  1. The polynomial form of the target sequence S is dealt with as a polynomial over Fq.
  
  2. A variable having the period of a given sequence is defined as long. Thus, one has to modify this if you would like to run them with long periodic sequence.
