#include<iostream>
#include<fstream>
#include<algorithm>
#include<iterator>
#include<string>
#include<vector>
#include<NTL/ZZ_pXFactoring.h>

using namespace std;
using namespace NTL;

void PrintPoly(ZZ_pX f) {
  for(long i = deg(f);i > 0;--i) {
    if(coeff(f,i) == 1) {
      cout << "x^" << i << " + ";
    }
  }
  if(coeff(f,0) == 1) {
    cout << coeff(f,0) << endl;
  }
}

void PrintPoly(Pair<ZZ_pX,long> f) {
  if(f.b > 1) {
    cout << "(";
  }
  for(long i = deg(f.a);i > 0;--i) {
    if(coeff(f.a,i) == 1) {
      cout << "x^" << i << " + ";
    }
  }
  if(coeff(f.a,0) == 1) {
    cout << 1;
  }

  if(f.b > 1) {
    cout << ")^" << f.b ;
  }
  cout << endl;
}

vector<int> SetSeq(char filename[]) {
  char chr;
  int tmp_num = 0;
  vector<int> S;
  vector<int> N;

  string tmp;
  ifstream ifs;

  ifs.open(filename);
  if(ifs.fail()) {
    cout << "ifs.open() failed." << endl;
    exit(1);
  }
  while(ifs >> chr) {
    if(isdigit(chr)) {
      N.push_back(chr-'0');
    }
    else{
      for(int i = 0; i < N.size(); i++){
        tmp_num = tmp_num * 10 + N[i];
      }
      S.push_back(tmp_num);
      tmp_num = 0;
      N.clear();
    }  
  }
  if(N.size() != 0 && S.size() != 0){
    for(int i = 0; i < N.size(); i++){
      tmp_num = tmp_num * 10 + N[i];
    }
    S.push_back(tmp_num);
    tmp_num = 0;
    N.clear();
  }
  ifs.close();
  cout << S.size() << endl;
  if(S.size() == 0){
    S = N;
  }
  return S;
}

unsigned long BerlekampMassey(vector<int> S) {

  /* variables for BM algorithm */
  ZZ_pX B,C,T,x;
  ZZ_p b, d;
  long L, m, n, N;

  /* variables for factorizing the derived polynomial */
  vec_pair_ZZ_pX_long factors;

  /* initial step */
  L = 0;       // linear complexity
  m = 1;       // the number of iteration since L and B would be updated
  b = 1;
  N = S.size();  // the length of input sequece
  B = 1;       // the copy of the last known C
  C = 1;       // a candiate for the feedback polynomial 
  SetX(x);

  /* main part */
  for(n = 0;n < N;++n) {
    d = S[n];     // discrepancy 
    for(long i = 1;i <= L;++i) {
      d += (coeff(C,i) * S[n-i]);
    }

    if(d == 0) {
      ++m;
    }
    else if(2*L <= n) {
      T = C;
      C = C - ((d * inv(b)) * power(x,m) * B);
      L = n + 1 - L;
      B = T;
      b = d;
      m = 1; 
    }
    else {
      C = C - ((d * inv(b)) * power(x,m) * B);
      ++m;
    }
    /* for complexity profile */
    /*
    cout << L << endl;
    */
  }

  T = C;
  for(long i = deg(T);i >= 0;--i) { 
    C[i] = T[deg(T)-i];
  }
  cout << "***** Information about generating polynomial *****" << endl;
  cout << "  C(x) = ";
  PrintPoly(C);
  cout << endl;
  
  factors = berlekamp(C,0);
  cout << "  The result of berlekamp factorization algorithm: " << endl;
  cout << "     Factors: " << endl;
  for(long i = 0;i < factors.length();++i) {
    cout << "       ";
    PrintPoly(factors[i]);
  }
  cout << endl;

  cout << "LC(S) = " << L << endl;

  return L;
}

int main(int argc, char* argv[]) {
  if(argc != 3) {
    cout << "./berlekamp-massey q filename" << endl;
    cout << "Note: Only the sequence described in the first line will be loaded." << endl;
    exit(1);
  }

  long q = strtol(argv[1],NULL,10);
  ZZ_p::init(ZZ(q)); 
  vector<int> S, T;

  S = SetSeq(argv[2]);
  cout << "S = ";
  for(long i = 0;i < (long)S.size();++i) {
    cout << S.at(i) << ",";
  }
  cout << endl;

  /* extend the given sequence having length N = period to N = 2*period */
  cout << "T = 2S = ";
  T = S;
  for(long i = 0;i < (long)S.size();++i) {
    T.push_back(S.at(i));
  }
  for(long i = 0;i < (long)T.size();++i) {
    cout << T.at(i) << ",";
  }
  cout << endl;

  BerlekampMassey(T);

  return 0;
}
